from django.contrib import admin
from . models import Petrol
from . models import Diesel
from . models import Electric


admin.site.register(Petrol)
admin.site.register(Diesel)
admin.site.register(Electric)




# Register your models here.
