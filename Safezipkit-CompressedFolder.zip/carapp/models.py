from django.db import models

# Create your models here.
class Petrol(models.Model):
    name=models.CharField(max_length=100)
    seating=models.IntegerField()
    colors=models.CharField(max_length=100,null=True)
    mileage=models.CharField(max_length=100)
    engine=models.CharField(max_length=100)
    def __str__(self):
        return self.name
class Diesel(models.Model):
    name=models.CharField(max_length=100)
    seating=models.IntegerField()
    colors=models.CharField(max_length=100,null=True)
    mileage=models.CharField(max_length=100)
    engine=models.CharField(max_length=100)
    def __str__(self):
        return self.name
class Electric(models.Model):
    name=models.CharField(max_length=100)
    seating=models.IntegerField()
    colors=models.CharField(max_length=100,null=True)
    mileage=models.CharField(max_length=100)
    engine=models.CharField(max_length=100)

    def __str__(self):
        return self.name
