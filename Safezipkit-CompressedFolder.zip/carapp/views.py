from django.shortcuts import render
from django.http import HttpResponse
from . models import Petrol
from . models import Diesel
from . models import Electric


s1=Diesel.objects.all()
def home(request):
    return render(request,'homee.html')
def features(request):
    return render(request,'features.html')
def services(request):
    return render(request,'services.html')
def review(request):
    return render(request,'review.html')
def contacts(request):
    return render(request,'contacts.html')
def category(request):
    return render(request,'category.html',{'s1':s1})
def details(request,id):
    details=Diesel.objects.get(id=id)
    return render(request,'diesel.html',{"details":details})


# Create your views here.
