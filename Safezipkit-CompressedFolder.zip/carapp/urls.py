from django.urls import path
from .import views

urlpatterns = [
    path('homee',views.home,name='homee'),
    path('features', views.features,name='features'),
    path('services', views.services,name='services'),
    path('review', views.review,name='review'),
    path('contacts', views.contacts,name='contacts'),
    path('category', views.category,name='category'),
    path('<int:id>',views.details,name='details')
    
    
]